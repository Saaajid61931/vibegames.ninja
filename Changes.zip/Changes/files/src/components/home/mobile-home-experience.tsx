"use client"

import { useLayoutEffect, useRef, useState, type ComponentProps } from "react"
import Link from "next/link"
import { ArrowDown, Gamepad2, Sparkles, X } from "lucide-react"
import { MobileReelsFeed } from "@/components/home/mobile-reels-feed"
import { Button } from "@/components/ui/button"

const INTRO_DISMISSED_KEY = "vibegames-home-intro-dismissed-v1"

type MobileHomeExperienceProps = ComponentProps<typeof MobileReelsFeed>

export function MobileHomeExperience({ games }: MobileHomeExperienceProps) {
  const scrollContainerRef = useRef<HTMLDivElement>(null)
  const feedStartRef = useRef<HTMLDivElement>(null)
  const [showIntroduction, setShowIntroduction] = useState(false)
  const [feedIsActive, setFeedIsActive] = useState(true)

  useLayoutEffect(() => {
    try {
      const introductionWasDismissed = window.localStorage.getItem(INTRO_DISMISSED_KEY) === "true"
      setShowIntroduction(!introductionWasDismissed)
      setFeedIsActive(introductionWasDismissed)
    } catch {
      setShowIntroduction(true)
      setFeedIsActive(false)
    }
  }, [])

  const scrollToGames = () => {
    const container = scrollContainerRef.current
    const feedStart = feedStartRef.current

    if (!container || !feedStart) return

    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches
    container.scrollTo({
      top: feedStart.offsetTop,
      behavior: prefersReducedMotion ? "auto" : "smooth",
    })
  }

  const handleScroll = () => {
    if (!showIntroduction) {
      setFeedIsActive(true)
      return
    }

    const container = scrollContainerRef.current
    const feedStart = feedStartRef.current
    if (!container || !feedStart) return

    const nextFeedIsActive = container.scrollTop >= feedStart.offsetTop - 2
    setFeedIsActive((current) => current === nextFeedIsActive ? current : nextFeedIsActive)
  }

  const dismissIntroduction = () => {
    try {
      window.localStorage.setItem(INTRO_DISMISSED_KEY, "true")
    } catch {
      // The feed still works when storage is unavailable.
    }

    setShowIntroduction(false)
    setFeedIsActive(true)
    window.requestAnimationFrame(() => {
      scrollContainerRef.current?.scrollTo({ top: 0, behavior: "auto" })
    })
  }

  return (
    <div
      ref={scrollContainerRef}
      onScroll={handleScroll}
      className="h-[100dvh] w-full snap-y snap-proximity overflow-y-auto overscroll-y-auto bg-[var(--color-base)] scrollbar-none"
    >
      <h1 className="sr-only">Play AI games made by the VibeGames Ninja community</h1>

      {showIntroduction ? (
        <section
          aria-labelledby="mobile-home-introduction-title"
          className="flex min-h-[44dvh] snap-start items-end pb-5 pl-[max(1rem,env(safe-area-inset-left))] pr-[max(1rem,env(safe-area-inset-right))] pt-[max(4.5rem,calc(env(safe-area-inset-top)+3.5rem))]"
        >
          <article className="relative w-full rounded-xl border-2 border-[var(--color-border-strong)] bg-[var(--color-surface)] p-5 shadow-[0_10px_30px_rgba(0,0,0,0.28)]">
            <button
              type="button"
              onClick={dismissIntroduction}
              className="absolute right-2 top-2 flex h-11 w-11 items-center justify-center rounded-md text-[var(--color-text-secondary)] transition-colors hover:bg-[var(--color-surface-2)] hover:text-[var(--color-text)]"
              aria-label="Dismiss welcome introduction"
            >
              <X className="h-5 w-5" aria-hidden="true" />
            </button>

            <p className="pr-12 font-pixel text-[9px] text-[var(--color-arcade-yellow)]">
              WELCOME TO VIBEGAMES NINJA
            </p>
            <h2
              id="mobile-home-introduction-title"
              className="mt-3 max-w-[18rem] text-2xl font-semibold leading-tight text-[var(--color-text)]"
            >
              Play. Get inspired. Build. Inspire others.
            </h2>
            <p className="mt-3 max-w-[21rem] text-sm leading-6 text-[var(--color-text-secondary)]">
              Discover games made with AI, meet the people creating them, and share something of your own.
            </p>

            <div className="mt-5 grid gap-3 min-[390px]:grid-cols-2">
              <Button type="button" size="lg" className="w-full gap-2" onClick={scrollToGames}>
                <Gamepad2 className="h-4 w-4" aria-hidden="true" />
                Start playing
                <ArrowDown className="h-4 w-4" aria-hidden="true" />
              </Button>
              <Link href="/upload" prefetch={false} className="block">
                <Button variant="outline" size="lg" className="w-full gap-2">
                  <Sparkles className="h-4 w-4" aria-hidden="true" />
                  Build a game
                </Button>
              </Link>
            </div>

            <p className="mt-4 text-xs text-[var(--color-text-tertiary)]">
              Made by the community. Open to everyone.
            </p>
          </article>
        </section>
      ) : null}

      <div
        ref={feedStartRef}
        className={`h-[100dvh] w-full snap-start ${feedIsActive ? "pointer-events-auto" : "pointer-events-none"}`}
      >
        <MobileReelsFeed games={games} />
      </div>
    </div>
  )
}
