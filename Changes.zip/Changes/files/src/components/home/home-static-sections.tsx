import Link from "next/link"
import { Gamepad2, Heart, Lightbulb, Sparkles, Upload, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { HomePageData } from "@/lib/home-page-data"

type HomeCategoryBarProps = {
  categoryLinks: HomePageData["categoryLinks"]
}

export function HomeCategoryBar() {
  return (
    <section
      aria-labelledby="home-discovery-options"
      className="overflow-hidden border-b-2 border-[var(--color-border-strong)] bg-[var(--color-surface)] py-4"
    >
      <div className="container mx-auto px-4">
        <h2 id="home-discovery-options" className="sr-only">Game discovery options</h2>
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <Link href="/games?sort=trending" prefetch={false}>
            <Button variant="arcade-outline" size="sm" className="rounded-full border-[var(--color-primary)] text-[var(--color-primary-hover)]">
              Trending
            </Button>
          </Link>
          <Link href="/games?sort=new" prefetch={false}>
            <Button variant="outline" size="sm" className="rounded-full">New creations</Button>
          </Link>
          <Link href="/games?sort=popular" prefetch={false}>
            <Button variant="outline" size="sm" className="rounded-full">Popular</Button>
          </Link>
          <Link href="/games?mobile=true" prefetch={false}>
            <Button variant="outline" size="sm" className="rounded-full">Mobile-ready</Button>
          </Link>
          <Link href="/games?editor=true" prefetch={false}>
            <Button variant="outline" size="sm" className="rounded-full">Level editors</Button>
          </Link>
        </div>
      </div>
    </section>
  )
}

export function HomeCommunityMomentumSection() {
  return (
    <section className="border-b-2 sm:border-b-4 border-[#4a4a6a] bg-[#11111d] py-10 sm:py-14">
      <div className="container mx-auto px-4">
        <div className="grid gap-4 lg:grid-cols-[1.3fr_1fr]">
          <div className="border-2 border-[#4a4a6a] bg-[#1a1a2e] p-5 sm:p-6">
            <p className="font-pixel text-[10px] text-[#22c55e]">COMMUNITY MOMENTUM</p>
            <h2 className="mt-2 font-pixel text-lg text-white sm:text-2xl">GAME JAMS DRIVE THE ENERGY</h2>
            <p className="mt-3 max-w-2xl font-arcade text-sm text-[#c9d1ff]">
              One strong jam system is better than scattered mini-events. Themes, deadlines, banners, submissions, and voting now live in one place.
            </p>
            <p className="mt-2 font-arcade text-sm text-[#8b93a6]">
              Join an active jam to build around a theme, get discovered faster, and give creators a clearer reason to upload now.
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <Link href="/jams" prefetch={false}>
                <Button variant="arcade">VIEW GAME JAMS</Button>
              </Link>
              <Link href="/upload" prefetch={false}>
                <Button variant="outline">UPLOAD A JAM BUILD</Button>
              </Link>
            </div>
          </div>

          <div className="border-2 border-[#4a4a6a] bg-[#1a1a2e] p-5 sm:p-6">
            <p className="font-pixel text-[10px] text-[#00d1ff]">WHY CREATORS USE THIS</p>
            <div className="mt-3 space-y-3 font-arcade text-sm text-[#c9d1ff]">
              <p>Every new launch gets a real discovery lane.</p>
              <p>You can mark one game as seeking feedback when you want eyes, not just likes.</p>
              <p>Your public profile now works more like a living portfolio than a file dump.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export function HomeFeatureGrid() {
  const steps = [
    {
      icon: Gamepad2,
      title: "PLAY",
      description: "Jump into community-made games in your browser.",
      color: "#facc15",
    },
    {
      icon: Lightbulb,
      title: "GET INSPIRED",
      description: "Find ideas, creators, genres, and experiments that stand out.",
      color: "#818cf8",
    },
    {
      icon: Upload,
      title: "BUILD",
      description: "Turn your own idea into something other people can play.",
      color: "#22c55e",
    },
    {
      icon: Heart,
      title: "INSPIRE OTHERS",
      description: "Share your work and help the next creator start.",
      color: "#f43f5e",
    },
  ] as const

  return (
    <section className="border-b-2 border-[var(--color-border-strong)] bg-[var(--color-base)] py-10 sm:py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl">
          <p className="font-pixel text-[10px] text-[var(--color-primary-hover)]">HOW THE COMMUNITY GROWS</p>
          <h2 className="mt-3 text-2xl font-semibold tracking-tight text-[var(--color-text)] sm:text-3xl">
            Play. Get inspired. Build. Inspire others.
          </h2>
        </div>

        <ol className="mt-7 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {steps.map((step, index) => {
            const Icon = step.icon
            return (
              <li key={step.title} className="rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)] p-5">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-md bg-[var(--color-surface-2)]">
                    <Icon className="h-5 w-5" style={{ color: step.color }} aria-hidden="true" />
                  </div>
                  <span className="font-pixel text-[9px] text-[var(--color-text-tertiary)]">
                    0{index + 1}
                  </span>
                </div>
                <h3 className="mt-4 font-pixel text-[11px]" style={{ color: step.color }}>
                  {step.title}
                </h3>
                <p className="mt-2 text-sm leading-6 text-[var(--color-text-secondary)]">
                  {step.description}
                </p>
              </li>
            )
          })}
        </ol>
      </div>
    </section>
  )
}

export function HomeCommunityCta() {
  return (
    <section className="border-b-2 border-[var(--color-border-strong)] bg-[var(--color-surface)] py-10">
      <div className="container mx-auto px-4">
        <div className="flex flex-col gap-6 rounded-xl border border-[var(--color-border-strong)] bg-[var(--color-surface-2)] p-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-2xl">
            <p className="font-pixel text-[10px] text-[var(--color-success)]">FROM PLAYER TO CREATOR</p>
            <h2 className="mt-3 text-2xl font-semibold tracking-tight text-[var(--color-text)]">
              Inspired? Build something of your own.
            </h2>
            <p className="mt-2 text-sm leading-6 text-[var(--color-text-secondary)] sm:text-base">
              Start with an idea you want to play, then share it with the community when it is ready.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <Link href="/upload" prefetch={false}>
              <Button size="lg" className="gap-2">
                <Sparkles className="h-5 w-5" aria-hidden="true" />
                Build a game
              </Button>
            </Link>
            <Link href="/games" prefetch={false}>
              <Button variant="outline" size="lg" className="gap-2">
                <Gamepad2 className="h-5 w-5" aria-hidden="true" />
                Keep playing
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

export function HomeDiscoveryShortcuts({ categoryLinks }: HomeCategoryBarProps) {
  return (
    <section className="border-b-2 border-[var(--color-border-strong)] bg-[var(--color-base)] py-12">
      <div className="container mx-auto px-4">
        <div className="mb-8 max-w-3xl">
          <div className="mb-2 flex items-center gap-2">
            <Zap className="h-5 w-5 text-[var(--color-primary-hover)]" aria-hidden="true" />
            <span className="font-pixel text-[10px] text-[var(--color-primary-hover)]">DISCOVERY SHORTCUTS</span>
          </div>
          <h2 className="text-2xl font-semibold tracking-tight text-[var(--color-text)] sm:text-3xl">
            Choose how you want to play.
          </h2>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Link href="/games?mobile=true" prefetch={false} className="group rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)] p-5 transition-all hover:-translate-y-1 hover:border-[var(--color-success)]">
            <p className="font-pixel text-[10px] text-[var(--color-success)]">PLAY ANYWHERE</p>
            <h3 className="mt-2 text-base font-semibold text-[var(--color-text)]">Mobile-friendly games</h3>
            <p className="mt-3 text-sm leading-6 text-[var(--color-text-secondary)]">Touch-ready games for shorter sessions and smaller screens.</p>
          </Link>
          <Link href="/games?editor=true" prefetch={false} className="group rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)] p-5 transition-all hover:-translate-y-1 hover:border-[var(--color-arcade-yellow)]">
            <p className="font-pixel text-[10px] text-[var(--color-arcade-yellow)]">MAKE IT YOURS</p>
            <h3 className="mt-2 text-base font-semibold text-[var(--color-text)]">Level editor picks</h3>
            <p className="mt-3 text-sm leading-6 text-[var(--color-text-secondary)]">Play games with tools for remixing levels and ideas.</p>
          </Link>
          <Link href="/jams" prefetch={false} className="group rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)] p-5 transition-all hover:-translate-y-1 hover:border-[var(--color-arcade-red)]">
            <p className="font-pixel text-[10px] text-[var(--color-arcade-red)]">BUILD TOGETHER</p>
            <h3 className="mt-2 text-base font-semibold text-[var(--color-text)]">Community game jams</h3>
            <p className="mt-3 text-sm leading-6 text-[var(--color-text-secondary)]">Create around a shared theme and see what other builders make.</p>
          </Link>
        </div>

        <div className="mt-6 flex flex-wrap gap-3">
          {categoryLinks.map((category) => (
            <Link key={category.value} href={category.href} prefetch={false}>
              <Button variant="outline" size="sm" className="rounded-full">
                {category.label}
              </Button>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
