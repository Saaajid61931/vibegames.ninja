import Link from "next/link"
import { ArrowRight, Gamepad2, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { HomePageData } from "@/lib/home-page-data"
import { formatNumber } from "@/lib/utils"

type HomeHeroSectionProps = {
  stats: HomePageData["stats"]
}

export function HomeHeroSection({ stats }: HomeHeroSectionProps) {
  const hasCommunityStats = stats.games > 0 || stats.creators > 0 || stats.plays > 0

  return (
    <section className="relative overflow-hidden border-b-2 border-[var(--color-border-strong)] bg-[var(--color-base)]">
      <div className="absolute inset-0 pixel-bg opacity-40" aria-hidden="true" />

      <div className="container relative mx-auto px-4 py-10 lg:py-14">
        <div className="max-w-5xl">
          <p className="font-pixel text-[10px] text-[var(--color-arcade-yellow)]">
            THE COMMUNITY FOR AI GAMES
          </p>

          <h1 className="mt-4 max-w-4xl text-4xl font-semibold leading-[1.05] tracking-[-0.035em] text-[var(--color-text)] lg:text-6xl">
            Play what people are building with AI.
          </h1>

          <p className="mt-5 max-w-3xl text-base leading-7 text-[var(--color-text-secondary)] sm:text-lg">
            VibeGames Ninja is a community for discovering games, finding inspiration, building your own ideas, and inspiring what comes next.
          </p>

          <div className="mt-7 flex flex-wrap gap-3">
            <Link href="/games" prefetch={false}>
              <Button variant="arcade" size="lg" className="gap-2">
                <Gamepad2 className="h-5 w-5" aria-hidden="true" />
                Explore games
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Button>
            </Link>
            <Link href="/upload" prefetch={false}>
              <Button variant="outline" size="lg" className="gap-2">
                <Sparkles className="h-5 w-5" aria-hidden="true" />
                Build a game
              </Button>
            </Link>
          </div>

          <div className="mt-7 flex flex-wrap items-center gap-x-3 gap-y-2 text-sm text-[var(--color-text-tertiary)]">
            <span>Made by creators. Played by everyone.</span>
            {hasCommunityStats ? (
              <>
                <span aria-hidden="true">•</span>
                <span>{formatNumber(stats.games)} games</span>
                <span aria-hidden="true">•</span>
                <span>{formatNumber(stats.creators)} creators</span>
                <span aria-hidden="true">•</span>
                <span>{formatNumber(stats.plays)} plays</span>
              </>
            ) : null}
          </div>

          <div className="mt-7 flex max-w-3xl flex-wrap items-center gap-2 border-t border-[var(--color-border)] pt-5 text-xs font-medium text-[var(--color-text-secondary)] sm:text-sm">
            <span>Play</span>
            <ArrowRight className="h-3.5 w-3.5 text-[var(--color-primary)]" aria-hidden="true" />
            <span>Get inspired</span>
            <ArrowRight className="h-3.5 w-3.5 text-[var(--color-primary)]" aria-hidden="true" />
            <span>Build</span>
            <ArrowRight className="h-3.5 w-3.5 text-[var(--color-primary)]" aria-hidden="true" />
            <span>Inspire others</span>
          </div>
        </div>
      </div>
    </section>
  )
}
