import type { Metadata } from "next"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { GameOfTheDay } from "@/components/games/game-of-the-day"
import { RecentlyPlayedDeferred } from "@/components/games/recently-played-deferred"
import { ActiveJamBanner } from "@/components/jams/active-jam-banner"
import { HomeGameLane } from "@/components/home/home-game-lane"
import { HomeHeroSection } from "@/components/home/home-hero-section"
import { MobileHomeExperience } from "@/components/home/mobile-home-experience"
import {
  HomeCategoryBar,
  HomeCommunityCta,
  HomeDiscoveryShortcuts,
  HomeFeatureGrid,
} from "@/components/home/home-static-sections"
import { getHomePageData } from "@/lib/home-page-data"
import { SITE_NAME, SITE_URL } from "@/lib/site"

export const revalidate = 60

const homepageDescription = "Discover and play games made with AI, get inspired by creators, and build something of your own with the VibeGames Ninja community."

export const metadata: Metadata = {
  title: "Play AI Games, Get Inspired & Build",
  description: homepageDescription,
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: `${SITE_NAME} - Play AI Games Made by the Community`,
    description: homepageDescription,
    url: SITE_URL,
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: `${SITE_NAME} - Play AI Games Made by the Community`,
    description: homepageDescription,
  },
}

export default async function HomePage() {
  const {
    stats,
    gameOfTheMonth,
    games,
    mobileGames,
    editorGames,
    justLaunchedGames,
    needsFeedbackGames,
    updatedThisWeekGames,
    categoryLinks,
    allMobileGames,
  } = await getHomePageData()

  const websiteJsonLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: SITE_NAME,
    url: SITE_URL,
    description: homepageDescription,
    potentialAction: {
      "@type": "SearchAction",
      target: `${SITE_URL}/games?q={search_term_string}`,
      "query-input": "required name=search_term_string",
    },
  }

  const organizationJsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: SITE_NAME,
    url: SITE_URL,
    logo: `${SITE_URL}/icon.svg`,
  }

  return (
    <>
      {/* Desktop homepage */}
      <div className="hidden min-h-screen flex-col bg-[var(--color-base)] md:flex hidden-mobile-landscape">
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteJsonLd) }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationJsonLd) }} />
        <Header prefetchLinks={false} />

        <main className="flex-1">
          <HomeHeroSection stats={stats} />
          <HomeCategoryBar />

          <RecentlyPlayedDeferred
            games={[...games, ...mobileGames, ...editorGames]}
            animateThumbnailSlides={false}
          />

          <HomeGameLane
            eyebrow="PLAY FIRST"
            title="FEATURED COMMUNITY PICKS"
            description="A hand-picked starting point for playing what community creators have shared."
            actionHref="/games?sort=trending"
            actionLabel="EXPLORE GAMES"
            games={games}
            animateThumbnailSlides={false}
          />

          <HomeFeatureGrid />
          <ActiveJamBanner />

          {gameOfTheMonth?.game ? (
            <GameOfTheDay
              game={gameOfTheMonth.game}
              monthlyStars={gameOfTheMonth.monthlyStars}
              monthlyRatings={gameOfTheMonth.monthlyRatings}
            />
          ) : null}

          {justLaunchedGames.length > 0 ? (
            <HomeGameLane
              eyebrow="NEW CREATIONS"
              title="FRESH FROM THE COMMUNITY"
              actionHref="/games?sort=new"
              actionLabel="SEE NEW GAMES"
              games={justLaunchedGames}
              sectionClassName="bg-[var(--color-surface)]"
              animateThumbnailSlides={false}
            />
          ) : null}

          {needsFeedbackGames.length > 0 ? (
            <HomeGameLane
              eyebrow="CREATOR SUPPORT"
              title="GAMES LOOKING FOR FEEDBACK"
              description="Play something new and leave a useful reaction or comment for its creator."
              actionHref="/games"
              actionLabel="PLAY & RESPOND"
              games={needsFeedbackGames}
              animateThumbnailSlides={false}
            />
          ) : null}

          <HomeCommunityCta />

          {updatedThisWeekGames.length > 0 ? (
            <HomeGameLane
              eyebrow="ACTIVE CREATORS"
              title="UPDATED THIS WEEK"
              actionHref="/games"
              actionLabel="SEE ALL GAMES"
              games={updatedThisWeekGames}
              sectionClassName="bg-[var(--color-surface)]"
              animateThumbnailSlides={false}
            />
          ) : null}

          <HomeDiscoveryShortcuts categoryLinks={categoryLinks} />

          {mobileGames.length > 0 ? (
            <HomeGameLane
              eyebrow="PLAY ANYWHERE"
              title="MADE FOR PHONE SCREENS"
              actionHref="/games?mobile=true"
              actionLabel="SEE MOBILE GAMES"
              games={mobileGames}
              animateThumbnailSlides={false}
            />
          ) : null}

          {editorGames.length > 0 ? (
            <HomeGameLane
              eyebrow="REMIX-FRIENDLY"
              title="GAMES WITH LEVEL EDITORS"
              actionHref="/games?editor=true"
              actionLabel="BROWSE EDITOR GAMES"
              games={editorGames}
              sectionClassName="bg-[var(--color-surface)]"
              animateThumbnailSlides={false}
            />
          ) : null}
        </main>

        <Footer prefetchLinks={false} />
      </div>

      {/* Mobile feed-first homepage */}
      <div className="block h-[100dvh] w-full overflow-hidden bg-[var(--color-base)] md:hidden block-mobile-landscape">
        <MobileHomeExperience games={allMobileGames} />
      </div>
    </>
  )
}
