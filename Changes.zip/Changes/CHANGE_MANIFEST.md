# Change Manifest

Base commit: `38012ab6e39bce710fc5686431bac20d73397660`

## Summary
Improves the existing VibeGames Ninja homepage with a compact community introduction, play-first desktop discovery, an honest discovery filter bar, and a dismissible mobile welcome item that preserves the existing reels feed and routes.

## Files

### MODIFY `src/app/page.tsx`
Destination: `src/app/page.tsx`
Old ranges: `6,6; 13,27; 47,7; 57,7; 75,8; 84,11; 98,26; 125,33; 160,8; 176,7; 185,9`
New ranges: `6,7; 14,28; 49,6; 58,7; 76,8; 85,24; 112,14; 127,25; 154,8; 170,7; 179,9`
Purpose: Reorder the desktop homepage around play-first discovery, use the new mobile feed introduction, and align homepage SEO copy with the community positioning.

### MODIFY `src/components/home/home-hero-section.tsx`
Destination: `src/components/home/home-hero-section.tsx`
Old ranges: `1,74`
New ranges: `1,72`
Purpose: Replace the oversized arcade hero with a compact desktop introduction that makes playing primary and building secondary while retaining real community statistics.

### MODIFY `src/components/home/home-static-sections.tsx`
Destination: `src/components/home/home-static-sections.tsx`
Old ranges: `1,5; 9,26; 75,48; 124,43; 170,40`
New ranges: `1,5; 9,29; 78,66; 145,32; 180,40`
Purpose: Add honest discovery shortcuts, explain the Play to Inspire cycle, and turn the creation prompt into a lightweight community invitation.

### ADD `src/components/home/mobile-home-experience.tsx`
Destination: `src/components/home/mobile-home-experience.tsx`
Purpose: Add the dismissible, locally persisted mobile introduction before the existing reels feed without changing the feed implementation.
